AI VISION STUDIO — NETLIFY + REAL AI STARTER

FILES
- index.html: website with chat connected to the backend endpoint
- netlify/functions/chat.mjs: secure server-side function; the API key is never placed in browser code
- netlify.toml: tells Netlify where the site and function are

IMPORTANT
This is starter code, not a deployed or tested live service. The AI will not work until the project is deployed with the function and OPENAI_API_KEY environment variable configured. API use may cost money. Ask a parent/guardian to help with accounts or billing that require an adult, and check pricing/limits before enabling paid API use.

DEPLOYMENT NOTES
1. Deploy the whole project folder/repository to Netlify, not only index.html. The netlify/functions/chat.mjs file and netlify.toml must be included.
2. In Netlify, open your site's Project configuration / Site configuration > Environment variables and add:
   Key: OPENAI_API_KEY
   Value: (your private API key from the OpenAI API dashboard)
   Keep the key private. Never put it in index.html, public code, screenshots, or chat messages.
3. Optionally add OPENAI_MODEL with a model available to your API account. Default in this starter is gpt-6-astra; change it if that model is not enabled for your account.
4. Redeploy after setting environment variables.
5. Open the deployed site and test the chat. If it does not work, inspect Netlify function logs.

CURRENT LIMITATIONS
- Chat messages are sent to the AI for a reply but are not stored or automatically forwarded to the owner.
- The project request form creates a WhatsApp message that the customer must choose to send.
- There is no database, authentication, or advanced rate limiting. Before public launch, add rate limiting/abuse protection and test costs with an adult helping.
- The business owner must review and approve prices and timelines.
