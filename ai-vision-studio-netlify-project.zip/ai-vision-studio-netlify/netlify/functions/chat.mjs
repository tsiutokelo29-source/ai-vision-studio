const SYSTEM_INSTRUCTIONS = `You are the customer-service assistant for AI Vision Studio, a small creative service business in South Africa.
You can discuss website design, advertisements, logo design, invitation cards, business menus, and custom design ideas.
Be friendly, concise, and use clear English. You may naturally understand South African English and Mzansi slang.
Ask only for details needed to understand a project, such as service type, business/occasion, desired wording, style, colours, features, and deadline if relevant.
Never invent prices, discounts, deadlines, guarantees, policies, or claim an order has been accepted. The owner must review and approve all prices and timelines. If asked about price, explain that the owner will review the project details and provide a quote.
Encourage customers to use the Request a project form or WhatsApp contact button to send a request to the owner. Do not claim that this chat is stored or automatically sent to the owner.
Never request passwords, bank PINs, card details, identity documents, or unnecessary sensitive information. Do not claim to be a human. If unsure, say the owner can follow up personally.`;

export default async (request) => {
  if (request.method !== 'POST') {
    return Response.json({ error: 'Use POST for chat messages.' }, { status: 405 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return Response.json({ error: 'The AI service has not been configured yet.' }, { status: 503 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: 'Please send a valid message.' }, { status: 400 });
  }

  const message = typeof body.message === 'string' ? body.message.trim() : '';
  if (!message || message.length > 1000) {
    return Response.json({ error: 'Message must be between 1 and 1000 characters.' }, { status: 400 });
  }

  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-6-astra',
        instructions: SYSTEM_INSTRUCTIONS,
        input: message,
        max_output_tokens: 350
      })
    });

    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('OpenAI API request failed:', upstream.status, result.error?.type || 'unknown_error');
      return Response.json({ error: 'The AI service could not answer right now. Please try again later.' }, { status: 502 });
    }

    const reply = (result.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === 'output_text')
      .map(item => item.text)
      .join('\n')
      .trim();

    if (!reply) {
      return Response.json({ error: 'The AI returned an empty reply. Please try again.' }, { status: 502 });
    }
    return Response.json({ reply }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('Chat function error:', error?.message || 'unknown error');
    return Response.json({ error: 'The AI service is temporarily unavailable.' }, { status: 500 });
  }
};
